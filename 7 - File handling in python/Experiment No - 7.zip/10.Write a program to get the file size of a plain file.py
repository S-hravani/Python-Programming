# Write a program to get the file size of a plain file
import os
file_size = os.path.getsize("C:/Users/Kulkarni/PycharmProjects/pythonProject/Experiment No - 7/demo.txt")
print("file size is = ",file_size," bytes")