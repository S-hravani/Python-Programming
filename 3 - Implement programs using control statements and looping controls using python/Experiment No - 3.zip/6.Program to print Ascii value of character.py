#Program to print Ascii value of character

char = input("enter a character = ")
print("Ascii Value of ",char," is",ord(char))