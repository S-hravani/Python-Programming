#Python function to sum all the numbers in a list

def sum(numbers):
    total = 0
    for x in numbers:
        total = total + x

    return total

print("sum = ",sum((8,2,3,0,7)))
