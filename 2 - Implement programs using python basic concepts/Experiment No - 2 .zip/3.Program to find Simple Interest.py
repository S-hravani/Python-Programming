#Program to find Simple Interest

P=int(input("Enter the Amount:"))
R=int(input("Enter the Rate of interest:"))
N=int(input("Enter the Period: "))

SimpleInterest=(P*R*N)/100

print("SimpleInterest=",SimpleInterest)

