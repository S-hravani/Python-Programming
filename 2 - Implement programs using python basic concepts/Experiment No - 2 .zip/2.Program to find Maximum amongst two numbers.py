#maximum amongst two numbers

a=int(input("Enter First Number:"))
b=int(input("Enter Second Number:"))
if a>b:
    print("{0} is Maximum".format(a))
else:
    print("{0} is Maximum".format(b))

