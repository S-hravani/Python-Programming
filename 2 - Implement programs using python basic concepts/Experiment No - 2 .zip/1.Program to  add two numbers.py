#Addition of two Numbers

a=int(input("Enter first Number:"))
b=int(input("Enter second Number:"))
sum=a+b
print("Addition of {0} and {1} is = {2}".format(a,b,sum))