#To perform addition,substraction,division and multiplication of three numbers

a=int(input("Enter First Number:"))
b=int(input("Enter Second Number:"))
c=int(input("Enter Third Number:"))

Addition=a+b+c
Substraction=a-b-c
multiplication=a*b*c
division=a/b/c

print(Addition)
print(Substraction)
print(multiplication)
print(division)