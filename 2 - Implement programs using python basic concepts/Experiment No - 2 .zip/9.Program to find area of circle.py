#Program to find area of circle

radius = int(input("Enter the radius = "))
area = 3.14 * radius * radius

print("Area of circle = ",area)