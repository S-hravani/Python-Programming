# Program to print factorial of given number using Math module

import math

num = int(input("Enter the Number to find its Factorial = "))
Factorial = math.factorial(num)
print("Facorial of ",num," is ",Factorial)