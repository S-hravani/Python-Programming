# Program to perform simple arithmetic operation using calc module

import calc

a = int(input("Enter first number = "))
b = int(input("Enter second number = "))

print(calc.add(a,b))
print(calc.multilication(a,b))
print(calc.division(a,b))
print(calc.mod(a,b))



