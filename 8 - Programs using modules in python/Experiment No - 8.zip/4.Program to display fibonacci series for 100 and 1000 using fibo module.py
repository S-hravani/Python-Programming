#Program to display fibonacci series for 100 and 1000 using fibo module

