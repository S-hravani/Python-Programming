#Program to perform simple arithmetic operation using calc module

def add(x,y):
    return x + y

def subtract(x,y):
    return x - y

def multilication(x,y):
    return x * y

def division(x,y):
    return x/y

def mod(x,y):
    return x%y

