list = [2,4,6,7,9]
sum = 0

for i in list:
    sum = sum + i

print(sum)