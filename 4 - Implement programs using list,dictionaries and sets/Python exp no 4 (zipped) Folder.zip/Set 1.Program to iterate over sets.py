#Program to iterate over sets

new_set = set([1,2,3,4,5,6,7])
for val in new_set:
   print(val)

test_set = set("shravani")
for i in test_set:
    print(i)