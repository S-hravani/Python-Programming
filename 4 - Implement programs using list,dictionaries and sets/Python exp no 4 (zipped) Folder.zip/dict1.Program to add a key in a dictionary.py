#Program to add a key in a dictionary

d={0:10,1:20}
print(d)
d.update({2:30})
print(d)