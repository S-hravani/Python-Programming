#Program to create set difference

set1 = set([1,2,3,4,5])
set2 = set([3,4,5,6,7])
set3 = set1.difference(set2)
print("Difference of set is : ",end = "")
print(set3)