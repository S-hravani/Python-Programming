#Program to convert tuple to a string

tuplex = ('s','h','r','a','v','a','n','i')
str = ''.join(tuplex)
print(str)