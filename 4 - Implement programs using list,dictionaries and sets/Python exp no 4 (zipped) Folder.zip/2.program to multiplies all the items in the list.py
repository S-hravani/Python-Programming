list = [3,5,7,9,10]
mul = 1

for i in list:
    mul = mul * i

print(mul)
