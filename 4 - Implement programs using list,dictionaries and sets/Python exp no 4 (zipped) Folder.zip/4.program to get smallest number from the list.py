list = [34,65,12,89,44,76,38,40]
min = list[0]

for num in list:
    if num<min:
        min = num

print(min)