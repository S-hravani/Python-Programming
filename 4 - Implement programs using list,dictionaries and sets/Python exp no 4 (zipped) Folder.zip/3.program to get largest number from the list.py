list = [34,65,12,89,44,76,38,40]
max = list[0]

for num in list:
    if num>max:
        max = num

print(max)