#Program to add members in set

colour_set = set()
print(set)
print("Add single element:")
colour_set.add("red")
print(colour_set)
print("Add multiple items:")
colour_set.update(["blue","white","pink"])
print(colour_set)