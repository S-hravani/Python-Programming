#program to check if list is empty

list = []
if not list:
    print("the list is empty")
else:
    print("the list is not empty")

