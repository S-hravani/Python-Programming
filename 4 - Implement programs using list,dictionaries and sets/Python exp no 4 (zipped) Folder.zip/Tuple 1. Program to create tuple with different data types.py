# Program to create tuple with different data types

tuplex = ("tuple", 5, 2.4, True)
print(tuplex)
