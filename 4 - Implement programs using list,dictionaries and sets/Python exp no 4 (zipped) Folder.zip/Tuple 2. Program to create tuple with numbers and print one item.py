#  Program to create tuple with numbers and print one item

tuplex = (1,2,3,4,5,6)
print(tuplex)
tuplex=5,
print(tuplex)