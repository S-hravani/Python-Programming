#Program to create an union of sets

set1 = set([1,2,3,4,5])
set2 = set([3,4,5,6,7])
set3 = set1.union(set2)
print("Union of set is : ",end = "")
print(set3)