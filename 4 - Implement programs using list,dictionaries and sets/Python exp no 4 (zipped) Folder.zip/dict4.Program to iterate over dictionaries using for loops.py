#Program to iterate over dictionaries using for loops

d={'Red':1,'Green':2,'Blue':3}

for colour_key,values in d.items():
    print(colour_key,"correspondce to",d[colour_key])
